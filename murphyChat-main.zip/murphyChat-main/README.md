# Murphy Chat

This is an AI assistant, built in Peaky blinders theme !
here i have used open ai models api's for the task and react based frontend.
